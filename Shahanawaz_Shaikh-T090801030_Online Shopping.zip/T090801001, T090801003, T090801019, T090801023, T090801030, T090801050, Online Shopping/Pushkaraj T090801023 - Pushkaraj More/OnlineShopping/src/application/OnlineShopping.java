package application;

import java.util.*;
import services.*;
import entities.*;

public class OnlineShopping {
	 
	private static ProductService productService = new ProductService();
	private static OrderService orderService = new OrderService();
	private static AdminService adminService = new AdminService();
	private static CustomerService customerService = new CustomerService(productService); // Pass productService

    public static void main(String[] args) {
    
    	
        initializeSampleData();
        showMainMenu();
    }

    private static void showMainMenu() {
    	Scanner scanner=new Scanner(System.in);
        while (true) {
        	
            System.out.println("\n=== Welcome to Online Shopping ===");
            System.out.println("1. Admin Menu");
            System.out.println("2. Customer Menu");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    showAdminMenu();
                    break;
                case 2:
                    showCustomerMenu();
                    break;
                case 3:
                    System.out.println("Exiting application...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void showAdminMenu() {
    	Scanner scanner=new Scanner(System.in);
        while (true) {
            System.out.println("\n=== Admin Menu ===");
            System.out.println("1. Add Product");
            System.out.println("2. Remove Product");
            System.out.println("3. View Products");
            System.out.println("4. View Orders");
            System.out.println("5. Update Order Status");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    productService.addProduct(scanner);
                    break;
                case 2:
                    productService.removeProduct(scanner);
                    break;
                case 3:
                    productService.viewProducts();
                    break;
                case 4:
                    orderService.viewOrders();
                    break;
                case 5:
                    orderService.updateOrderStatus(scanner);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void showCustomerMenu() {
    	Scanner scanner=new Scanner(System.in);
        while (true) {
            System.out.println("\n=== Customer Menu ===");
            System.out.println("1. Browse Products");
            System.out.println("2. Add Product to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Place Order");
            System.out.println("5. View Orders");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    productService.viewProducts();
                    break;
                case 2:
                    customerService.addToCart(scanner);
                    break;
                case 3:
                    customerService.viewCart();
                    break;
                case 4:
                    customerService.placeOrder(orderService);
                    break;
                case 5:
                    customerService.viewOrders();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void initializeSampleData() {
        productService.addSampleData();
    }
}
