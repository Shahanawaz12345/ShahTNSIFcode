package entities;
import java.util.*;
public class Admin extends User {
    public Admin(String username, String email) {
        super(username, email);
    }
}