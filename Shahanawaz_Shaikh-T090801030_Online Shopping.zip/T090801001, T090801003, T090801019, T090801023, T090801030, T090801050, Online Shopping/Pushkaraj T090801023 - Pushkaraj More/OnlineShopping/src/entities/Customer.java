
package entities;
import java.util.*;
import java.util.ArrayList;
public class Customer extends User {
    private String address;
    private ShoppingCart shoppingCart;
    private List<Order> orders = new ArrayList<>();

    public Customer(String username, String email, String address) {
        super(username, email);
        this.address = address;
        this.shoppingCart = new ShoppingCart();
    }
    
    public String getAddress() { return address; }
    public ShoppingCart getShoppingCart() { return shoppingCart; }
    public List<Order> getOrders() { return orders; }
    
    @Override
    public String toString() {
        return super.toString() + ", Customer [address=" + address + "]";
    }
}