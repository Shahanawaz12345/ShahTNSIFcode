package entities;

import java.util.*;

public class Order {
    private static int orderCounter = 1;
    private int orderId;
    private Customer customer;
    private Map<Product, Integer> products = new HashMap<>();
    private String status;

    public Order(Customer customer) {
        this.customer = customer;
        this.orderId = orderCounter++;
        this.status = "Pending";
    }
    
    public int getOrderId() { return orderId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public void addProduct(Product product, int quantity) {
        products.put(product, quantity);
        product.setStockQuantity(product.getStockQuantity() - quantity);
    }
    
    public void displayOrder() {
        System.out.println("Order ID: " + orderId + ", Status: " + status);
        for (Map.Entry<Product, Integer> entry : products.entrySet()) {
            System.out.println("  " + entry.getKey().getName() + ", Quantity: " + entry.getValue());
        }
    }
    
    @Override
    public String toString() {
        return "Order [orderId=" + orderId + ", customer=" + customer.getUsername() + ", status=" + status + "]";
    }
}
