package entities;
import java.util.*;
import services.*;


public class ShoppingCart {
    private Map<Product, Integer> items = new HashMap<>();
    
    public void addProduct(Product product, int quantity) {
        items.put(product, items.getOrDefault(product, 0) + quantity);
    }
    
    public void viewCart() {
        System.out.println("Shopping Cart:");
        if (items.isEmpty()) {
            System.out.println("Cart is empty.");
        } else {
            for (Map.Entry<Product, Integer> entry : items.entrySet()) {
                System.out.println(entry.getKey().getName() + " - Quantity: " + entry.getValue());
            }
        }
    }
    
    public Map<Product, Integer> getItems() { return items; }
}
