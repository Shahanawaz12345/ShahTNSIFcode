package services;
import java.util.*;

import entities.*;

public class CustomerService {
    private ProductService productService;
    private Customer customer;

    public CustomerService(ProductService productService) {
        this.productService = productService;
        this.customer = new Customer("Guest", "guest@example.com", "Default Address");
    }

    public void addToCart(Scanner scanner) {
        System.out.print("Enter Product ID to add to cart: ");
        int id = scanner.nextInt();
        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();
        
        Product product = productService.getProductById(id); // Use shared ProductService instance
        if (product != null) {
            customer.getShoppingCart().addProduct(product, quantity);
            System.out.println("✅ Product added to cart.");
        } else {
            System.out.println("❌ Product not found.");
        }
    }

    public void viewCart() {
        customer.getShoppingCart().viewCart();
    }

    public void placeOrder(OrderService orderService) {
        Order newOrder = new Order(customer);
        for (Map.Entry<Product, Integer> entry : customer.getShoppingCart().getItems().entrySet()) {
            newOrder.addProduct(entry.getKey(), entry.getValue());
        }
        orderService.placeOrder(newOrder);
        customer.getOrders().add(newOrder);
        customer.getShoppingCart().getItems().clear();
        System.out.println("✅ Order placed successfully!");
    }

    public void viewOrders() {
        customer.getOrders().forEach(System.out::println);
    }
}
